#!/usr/bin/env bash

refreshPermissions () {
    local pid="${1}"

    while kill -0 "${pid}" 2> /dev/null; do
        sudo -v
        sleep 10
    done
}

sudo -v
refreshPermissions "$$" &

read -p "Enter Master Node:" master

ssh-keyscan -H $master >> ~/.ssh/known_hosts

sshpass -p "Key5ight!" scp -o StrictHostKeyChecking=no -o UserKnownHostsFile=/dev/null keysight@$master:keyvm/vf/join.txt keyvm/vf/join.sh

sed -i '1s/^/sudo /' keyvm/vf/join.sh
sudo chmod +x keyvm/vf/join.sh

./keyvm/vf/join.sh

