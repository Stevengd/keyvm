#!/bin/bash
refreshPermissions () {
    local pid="${1}"

    while kill -0 "${pid}" 2> /dev/null; do
        sudo -v
        sleep 10
    done
}

sudo -v
refreshPermissions "$$" &

sudo kubeadm init --pod-network-cidr=172.16.10.0/24
sleep 30
mkdir -p $HOME/.kube
sleep 1
sudo cp -i /etc/kubernetes/admin.conf $HOME/.kube/config
sleep 1
sudo chown $(id -u):$(id -g) $HOME/.kube/config
sleep 5 
kubectl apply -f keyvm/3/yaml/calico.yaml
sleep 10
kubectl apply -f keyvm/3/yaml/dynamic-storage.yml
sleep 2
kubeadm token create --print-join-command > keyvm/vf/join.txt


