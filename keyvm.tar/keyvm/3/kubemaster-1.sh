#!/bin/bash
refreshPermissions () {
    local pid="${1}"

    while kill -0 "${pid}" 2> /dev/null; do
        sudo -v
        sleep 10
    done
}

sudo -v
refreshPermissions "$$" &

sudo kubeadm init --pod-network-cidr=172.16.10.0/24
sleep 10
mkdir -p $HOME/.kube
sudo cp -i /etc/kubernetes/admin.conf $HOME/.kube/config
sudo chown $(id -u):$(id -g) $HOME/.kube/config
kubectl apply -f keyvm/3/yaml/calico.yaml
sleep 5
kubectl apply -f keyvm/3/yaml/dynamic-storage.yml
sleep  2
kubectl taint node $HOSTNAME node-role.kubernetes.io/control-plane:NoSchedule-



