#!/usr/bin/env bash

source variables.txt

   kubectl get pod \
    -l app=ubtg2204 \
    -o custom-columns=name:metadata.name --no-headers \
    | xargs -I{} kubectl exec {} ./endpoint.install accept_license $chariotip
