#!/usr/bin/env bash

source variables.txt

helm install --set image.repository=$cloudlensip/sensor --insecure-skip-tls-verify --set sensor.server=$cloudlensip --set sensor.projectKey=$projecttoken --set privileged=true --set sensor.debug=false cloudtap cloudlens-sensor.tar.gz

