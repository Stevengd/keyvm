#!/usr/bin/env bash


source variables.txt

#export serverip=$serviceip
#export projecttoken=$projecttoken
#read -p "Enter Cloudlens Server IP: " serverip
#read -p "Enter the Project Key: " projecttoken
#read -p "Enter number of replicas: " replicas

echo
cat > nginx-cloudlens.yaml <<EOF
apiVersion: apps/v1
kind: Deployment
metadata:
  name: nginx-cloudlens
spec:
  selector:
    matchLabels:
      app: nginx
  replicas: $replicas
  template:
    metadata:
      labels:
        app: nginx
    spec:
      containers:
      - name: nginx
        image: nginx
        ports:
        - containerPort: 80
      - name: sidecar
        image: $cloudlensip/sensor
        args: ["--auto_update","y","--project_key","$projecttoken","--accept_eula","yes","--server","$cloudlensip", "--ssl_verify","no","--custom_tags", "name=nginx","source=K8s"]
        securityContext:
          allowPrivilegeEscalation: true
          privileged: true
          capabilities:
            add: ["SYS_RAWIO", "SYS_RESOURCE", "SYS_ADMIN", "NET_ADMIN", "NET_RAW"]

EOF


