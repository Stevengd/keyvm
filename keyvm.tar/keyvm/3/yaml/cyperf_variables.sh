#!/usr/bin/env bash


source variables.txt


#export serverip=$serviceip
#export projecttoken=$projecttoken
#read -p "Enter Cloudlens Server IP: " serverip
#read -p "Enter the Project Key: " projecttoken
#read -p "Enter number of replicas: " replicas

echo
cat > cyperf-server.yml <<EOF

apiVersion: apps/v1
kind: Deployment
metadata:
    name: cyperf-standalone
spec:
    replicas: $replicas
    selector:
        matchLabels:
            app: cyperf-agent
            run: cyperf-agent-server
    template:
        metadata:
            labels:
                app: cyperf-agent
                run: cyperf-agent-server
        spec:
            containers:
                -   name: cyperf-standalone
                    image: public.ecr.aws/keysight/cyperf-agent:latest
                    env:
                    -   name: AGENT_CONTROLLER
                        value: "$cyperf"
                    #   name: AGENT_MANAGEMENT_INTERFACE
                    #   value: "ens160"
                    #   name: AGENT_TEST_INTERFACE
                    #   value: "ens192"
                    -   name: AGENT_TAGS
                        value: "S=Good,owner=Steven"
                    securityContext:
                        privileged: false
                        capabilities:
                          add: ["NET_ADMIN", "IPC_LOCK", "NET_RAW"]
                    #readinessProbe:
                    #   httpGet:
                    #        path: /CyPerfHTTPHealthCheck
                    #        port: 80
                    #    periodSeconds: 5
                    resources:
                        limits:
                            memory: "4Gi"
                            #cpu: "3.5"
                            ## skipping requests means limits=requests
                            ## with 3.5 for 8 core node it should be able to run 2 replicas
                            ## but experiments needed to see how other pods react for perf configs.
                        requests:
                            memory: "2Gi"

            nodeSelector:
                agenttype: server
           # affinity:
           #     podAntiAffinity:
           #         requiredDuringSchedulingIgnoredDuringExecution:
           #         - labelSelector:
           #             matchExpressions:
           #             - key: app
           #               operator: In
           #               values:
           #               - cyperf-agent
           #           topologyKey: "kubernetes.io/hostname"


---

apiVersion: v1
kind: Service
metadata:
    name: cyperf-standalone-service
spec:
    #type: ClusterIP
    type: NodePort
    ports:
    - port: 8080
      protocol: TCP
      name: http
      targetPort: 8080
      nodePort: 30180
    selector:
        run: cyperf-agent-server

EOF


