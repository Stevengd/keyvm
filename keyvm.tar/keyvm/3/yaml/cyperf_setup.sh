#!/usr/bin/env bash


kubectl label nodes --all agenttype=server

echo "pass internal 1"


kubectl get nodes
