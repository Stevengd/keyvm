#!/usr/bin/env bash


source variables.txt



echo
cat > chariot-cloudlens.yaml <<EOF
apiVersion: apps/v1
kind: Deployment
metadata:
  name: ubtg2204
spec:
  selector:
    matchLabels:
      app: ubtg2204
  replicas: $replicas
  template:
    metadata:
      labels:
        app: ubtg2204
    spec:
      containers:
      - name: ubtg2204
        image: stevengd2004/ubtg2204:latest
        ports:
        - containerPort: 80
        command: [ "/bin/bash", "-c", "--" ]
        args: [ "while true; do sleep 30; done;" ]     
      - name: sidecar
        image: $cloudlensip/sensor
        args: ["--auto_update","y","--project_key","$projecttoken","--accept_eula","yes","--server","$cloudlensip","--ssl_verify","no","--custom_tags","name=chariot","source=K8s"]
        securityContext:
          allowPrivilegeEscalation: true
          privileged: true
          capabilities:
            add: ["SYS_RAWIO", "SYS_RESOURCE", "SYS_ADMIN", "NET_ADMIN", "NET_RAW"] 
        resources:
          limits:
            cpu: "4"
            memory: "4Gi"
          requests:
            cpu: "2"
            memory: "2Gi"

EOF


