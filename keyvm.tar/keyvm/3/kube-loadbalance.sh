#!/bin/bash

kubectl apply -f keyvm/3/yaml/metallb.yml
sleep 30
kubectl apply -f keyvm/3/yaml/metallb-config.yaml




