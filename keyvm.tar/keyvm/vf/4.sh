#!/usr/bin/env bash


read -p "Enter Cloudlens Server IP(press Enter if not used):" cloudlensip
read -p "Enter Cloudlens Project Token (press Enter if not used):" projecttoken

sudo cat > keyvm/vf/variables.txt <<EOF


cloudlensip=$cloudlensip
projecttoken=$projecttoken
chariotip=$chariotip
replicas=$replicas
cyperf=$cyperf

EOF


sudo ln keyvm/vf/variables.txt keyvm/3/yaml/variables.txt


