#!/usr/bin/env bash


read -p "Enter the static IP of the server in CIDR notation: " staticip
read -p "Enter the IP of your gateway: " gatewayip
read -p "Enter the IP of preferred nameservers (seperated by a coma if more than one): " nameserverip
read -p "Enter Hostname:" hostnameid
read -p "Enter Cloudlens Server IP:" cloudlensip
read -p "Enter Cloudlens Project Token:" projecttoken
read -p "Enter Chariot Server IP:" chariotip


sudo cat > keyvm/vf/variables.txt <<EOF

staticip=$staticip
gatewayip=$gatewayip
nameserverip=$nameserverip
hostnameid=$hostnameid
cloudlensip=$cloudlensip
projecttoken=$projecttoken
chariotip=$chariotip

EOF


sudo ln keyvm/vf/variables.txt keyvm/3/yaml/variables.txt



cat keyvm/vf/variables.txt

