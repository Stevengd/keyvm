#!/usr/bin/env bash


read -p "Enter Cloudlens Server IP(press Enter if not used):" cloudlensip

sudo cat > keyvm/vf/variables.txt <<EOF


cloudlensip=$cloudlensip

EOF


sudo ln keyvm/vf/variables.txt keyvm/3/yaml/variables.txt


