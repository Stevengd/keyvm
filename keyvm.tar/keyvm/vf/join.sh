sudo kubeadm join 10.22.6.13:6443 --token wnguoj.r4jah56fn1hvkclw --discovery-token-ca-cert-hash sha256:4850ace74df098555491380474253390cac4eb6acaa82031c8b45edbcef1c985 
