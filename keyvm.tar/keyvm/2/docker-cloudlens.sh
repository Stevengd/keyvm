#!/bin/bash

read -p "Enter Cloudlens Server IP:" cloudlensip
read -p "Enter Cloudlens Project Token:" projecttoken

sleep 1

echo Cloudlens Server: $cloudlensip
echo Cloudlens Token:  $projecttoken

echo "{\"insecure-registries\":[\"$cloudlensip\"]}" | sudo tee /etc/docker/daemon.json
sudo service docker restart

sleep 5

sudo docker run -v /lib/modules:/lib/modules -v /var/log/cloudlens:/var/log/cloudlens -v /:/host -v /var/run/docker.sock:/var/run/docker.sock --cap-add SYS_MODULE --cap-add SYS_RESOURCE --cap-add NET_RAW --cap-add NET_ADMIN --name cloudlens-agent -d --restart=always --net=host --log-opt max-size=50m --log-opt max-file=5 $cloudlensip/sensor --accept_eula yes --project_key $projecttoken --server $cloudlensip --ssl_verify no 

sleep 1

echo ==============================

sudo docker ps -a

echo ==============================

sleep 5
