#!/bin/bash

refreshPermissions () {
    local pid="${1}"

    while kill -0 "${pid}" 2> /dev/null; do
        sudo -v
        sleep 10
    done
}

sudo -v
refreshPermissions "$$" &


sudo docker network create gravnet
sudo docker pull gravwell/gravwell
sudo docker pull gravwell/netflow_capture
sudo docker run -d -e DISABLE_simple_relay=TRUE -e GRAVWELL_INGEST_AUTH=SuperSekritTokens -e TZ=America/Denver
gravwell/gravwell:latest

sleep 10

sudo docker run --net gravnet -p 8080:80 -p 4023:4023 -p 4024:4024 -d -e GRAVWELL_INGEST_SECRET=MyIngestSecret -e GRAVWELL_INGEST_AUTH=MyIngestSecret -e GRAVWELL_CONTROL_AUTH=MyControlSecret -e GRAVWELL_SEARCHAGENT_AUTH=MySearchAgentAuth --name gravwell gravwell/gravwell:latest
sudo docker run -d --net gravnet -p 2055:2055/udp -e GRAVWELL_CLEARTEXT_TARGETS=gravwell -e GRAVWELL_INGEST_SECRET=MyIngestSecret gravwell/netflow_capture

