
#!/bin/bash

#sudo docker pull lscr.io/linuxserver/rdesktop:latest

#docker run -d --name=rdesktop --security-opt seccomp=unconfined `#optional` -e PUID=1000 -e PGID=1000 -p 3389:3389 -v /var/run/docker.sock:/var/run/docker.sock -v /path/to/data:/config --device /dev/dri:/dev/dri --shm-size="1gb" --restart unless-stopped lscr.io/linuxserver/rdesktop:latest
 
#sudo docker run -d \
#  --name=rdesktop \
#  --security-opt seccomp=unconfined `#optional` \
#  -e PUID=1000 \
#  -e PGID=1000 \
#  -e TZ=Etc/UTC \
#  -p 3389:3389 \
#  -v /var/run/docker.sock:/var/run/docker.sock `#optional` \
#  -v /path/to/data:/config `#optional` \
#  --device /dev/dri:/dev/dri `#optional` \
#  --shm-size="1gb" `#optional` \
#  --restart unless-stopped \
#  lscr.io/linuxserver/rdesktop:latest


#sudo docker ps -a


#sudo docker pull kasmweb/desktop:1.13.0
#sudo docker run -id  -p 6901:6901 -e VNC_PW=Key5ight! kasmweb/desktop:1.13.0

sudo docker pull kasmweb/ubuntu-focal-desktop:1.13.0
sudo docker run -id --shm-size="2g" -p 6902:6902 --user=root --name=desktop --privileged=true -e NO_VNC_PORT=6902 -e VNC_PORT=5902 -e VNC_PW=Key5ight! kasmweb/ubuntu-focal-desktop:1.13.0

