#!/bin/bash

webip=$(ip -o route get to 8.8.8.8 | sed -n 's/.*src \([0-9.]\+\).*/\1/p')


sudo docker pull kasmweb/desktop:1.14.0
sudo docker run -id --shm-size="2g" -p 6902:6902 --user=root --name=desktop --privileged=true -e NO_VNC_PORT=6902 -e VNC_PORT=5902 -e VNC_PW=Key5ight! kasmweb/desktop:1.14.0

printf '%10s %32s %32s\n' interface ipaddress macaddress
printf '%s\n' '----------------------------------------------------------------------------'
for each in $(ip address | grep -oP '(^[\d]+:\s)\K[\d\w]+'); do
  mac=$(ip address show ${each} | grep -oP '(?<=link/ether\s)\K[\da-f:]+|(?<=link/loopback\s)\K[\da-f:]+')
  for address in $(ip address show ${each} | grep -oP '(?<=inet\s)\K[\d.]+|(?<=inet6\s)\K[\da-f:]+'); do
    printf '%10s %32s %32s\n' ${each} ${address} ${mac}
  done
done

echo "Use any external IP address to connect to Web UI on port 6902 ==>  https://$webip:6902   "
echo "The UserLogin is following: kasm_user/Key5ight! "
read -n 1 -s -r -p "Press any key to continue"

