#!/bin/bash

sudo apt update -y
sudo apt install snapd
sleep 20
sudo snap install semaphore
sleep 5
sudo snap stop semaphore
sudo semaphore user add --admin \
--login keysight \
--name=keysight \
--email=keysight@keysight.com \
--password=Key5ight!

sudo snap start semaphore

