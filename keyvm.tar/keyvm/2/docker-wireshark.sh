#!/bin/bash

webip=$(ip -o route get to 8.8.8.8 | sed -n 's/.*src \([0-9.]\+\).*/\1/p')

sudo docker pull lscr.io/linuxserver/wireshark:latest

sudo docker run -d --name=wireshark --net=host --cap-add=NET_ADMIN --security-opt seccomp=unconfined -e PUID=1000 -e PGID=1000 -e CUSTOM_PORT=4000 -e CUSTOM_HTTPS_PORT=4001 -v /path/to/config:/config --restart unless-stopped  lscr.io/linuxserver/wireshark:latest

printf '%10s %32s %32s\n' interface ipaddress macaddress
printf '%s\n' '----------------------------------------------------------------------------'
for each in $(ip address | grep -oP '(^[\d]+:\s)\K[\d\w]+'); do
  mac=$(ip address show ${each} | grep -oP '(?<=link/ether\s)\K[\da-f:]+|(?<=link/loopback\s)\K[\da-f:]+')
  for address in $(ip address show ${each} | grep -oP '(?<=inet\s)\K[\d.]+|(?<=inet6\s)\K[\da-f:]+'); do
    printf '%10s %32s %32s\n' ${each} ${address} ${mac}
  done
done

echo "Use any external IP address connect to Web UI on port 4001 ==> https://$webip:4001  "
read -n 1 -s -r -p "Press any key to continue"
