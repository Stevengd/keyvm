
#!/bin/bash

sudo docker pull lscr.io/linuxserver/wireshark:latest

sudo docker run -d --name=wireshark --net=host --cap-add=NET_ADMIN --security-opt seccomp=unconfined -e PUID=1000 -e PGID=1000 -e CUSTOM_PORT=4000 -e CUSTOM_HTTPS_PORT=4001 -v /path/to/config:/config --restart unless-stopped  lscr.io/linuxserver/wireshark:latest
