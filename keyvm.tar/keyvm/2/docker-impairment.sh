#!/bin/bash

sudo docker pull ubuntu
#sudo docker run --name impair --network host --restart always -id ubuntu bash

