#!/bin/bash

echo "======================================"
echo "Available Interfaces:"
ip -o link show | awk -F': ' '{print $2}'
echo "======================================"


read -p "Enter interface for monitoring: " port

sudo docker pull ntop/ntopng:stable
sudo docker run -d -p 3000:3000 -v $(pwd)/ntopng.license:/etc/ntopng.license:ro --net=host ntop/ntopng:stable -i $port
