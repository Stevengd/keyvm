#!/bin/bash


read -p "Enter Chariot Server IP:" chariotip

sudo docker pull stevengd2004/ubtg2204:latest
sudo docker run -id stevengd2004/ubtg2204:latest  sh

sleep 5 


echo ==================================

sudo docker ps -a

echo =================================



container=$(sudo docker ps -l -q)

sleep 5

sudo docker exec -it $container ./endpoint.install accept_license $chariotip
