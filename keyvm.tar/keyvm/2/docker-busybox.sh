
#!/bin/bash

sudo docker pull busybox
sudo docker run -id  busybox  sh 

