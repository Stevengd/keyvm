#!/bin/bash


sudo docker pull stevengd2004/vyos:1.4.3

sudo docker run -d -v /lib/modules:/lib/modules -v vyos-config:/opt/vyatta/etc/config/ --privileged --network host --restart always --name vyos -d stevengd2004/vyos:1.4.3

sleep 2

echo "**********************CONFIGURING VYOS FOR REMOTE ACCESS***************************"

sleep 30 

cat <<EOF | sudo docker exec --interactive vyos su vyos
sudo ./config1.sh
EOF

echo "********************CONFIGURATION COMPLETE****************************************"

printf '%10s %32s %32s\n' interface ipaddress macaddress
printf '%s\n' '----------------------------------------------------------------------------'
for each in $(ip address | grep -oP '(^[\d]+:\s)\K[\d\w]+'); do
  mac=$(ip address show ${each} | grep -oP '(?<=link/ether\s)\K[\da-f:]+|(?<=link/loopback\s)\K[\da-f:]+')
  for address in $(ip address show ${each} | grep -oP '(?<=inet\s)\K[\d.]+|(?<=inet6\s)\K[\da-f:]+'); do
    printf '%10s %32s %32s\n' ${each} ${address} ${mac}
  done
done

echo "Use any external IP address to SSH to vyos on port 23 (example 192.168.10.10:23)"
read -n 1 -s -r -p "Press any key to continue" 


exit
