#!/bin/bash


sudo docker pull stevengd2004/vyos:1.4.3

sudo docker run -d -v /lib/modules:/lib/modules -v vyos-config:/opt/vyatta/etc/config/ --privileged --network host --restart always --name vyos -d stevengd2004/vyos:1.4.3

sleep 10

cat <<EOF | sudo docker exec --interactive vyos su vyos
sudo ./config1.sh
EOF


exit
