
#!/bin/bash

sudo docker pull lscr.io/linuxserver/kasm:latest

sudo docker run -d \
  --name=kasm \
  --privileged \
  -e KASM_PORT=4443 \
  -p 3000:3000 \
  -p 443:443 \
  -v /path/to/data:/opt \
  -v /path/to/profiles:/profiles `#optional` \
  -v /dev/input:/dev/input `#optional` \
  -v /run/udev/data:/run/udev/data `#optional` \
  --restart unless-stopped \
  lscr.io/linuxserver/kasm:latest


sleep 2

printf '%10s %32s %32s\n' interface ipaddress macaddress
printf '%s\n' '----------------------------------------------------------------------------'
for each in $(ip address | grep -oP '(^[\d]+:\s)\K[\d\w]+'); do
  mac=$(ip address show ${each} | grep -oP '(?<=link/ether\s)\K[\da-f:]+|(?<=link/loopback\s)\K[\da-f:]+')
  for address in $(ip address show ${each} | grep -oP '(?<=inet\s)\K[\d.]+|(?<=inet6\s)\K[\da-f:]+'); do
    printf '%10s %32s %32s\n' ${each} ${address} ${mac}
  done
done

echo "Use any external IP address to connect to Web UI through port 4443 (example https://192.168.10.10:4443)"
read -n 1 -s -r -p "Press any key to continue"

exit
