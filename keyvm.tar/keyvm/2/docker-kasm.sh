
#!/bin/bash

#sudo docker pull lscr.io/linuxserver/rdesktop:latest

#docker run -d --name=rdesktop --security-opt seccomp=unconfined `#optional` -e PUID=1000 -e PGID=1000 -p 3389:3389 -v /var/run/docker.sock:/var/run/docker.sock -v /path/to/data:/config --device /dev/dri:/dev/dri --shm-size="1gb" --restart unless-stopped lscr.io/linuxserver/rdesktop:latest
 
#sudo docker run -d \
#  --name=rdesktop \
#  --security-opt seccomp=unconfined `#optional` \
#  -e PUID=1000 \
#  -e PGID=1000 \
#  -e TZ=Etc/UTC \
#  -p 3389:3389 \
#  -v /var/run/docker.sock:/var/run/docker.sock `#optional` \
#  -v /path/to/data:/config `#optional` \
#  --device /dev/dri:/dev/dri `#optional` \
#  --shm-size="1gb" `#optional` \
#  --restart unless-stopped \
#  lscr.io/linuxserver/rdesktop:latest


#sudo docker ps -a


#sudo docker pull kasmweb/desktop:1.13.0
#sudo docker run -id  -p 6901:6901 -e VNC_PW=Key5ight! kasmweb/desktop:1.13.0

#sudo docker pull kasmweb/ubuntu-focal-desktop:1.13.0
#sudo docker run -id --shm-size=512m -p 6901:6901 -e VNC_PW=Key5ight! kasmweb/ubuntu-focal-desktop:1.13.0

#sudo docker run -id --shm-size=512m -p 7901:7901 -e VNC_PW=Key5ight! kasmweb/ubuntu-focal-desktop:1.13.0

sudo docker pull lscr.io/linuxserver/kasm:latest

sudo docker run -d \
  --name=kasm \
  --privileged \
  -e KASM_PORT=4443 \
  -p 3000:3000 \
  -p 443:443 \
  -v /path/to/data:/opt \
  -v /path/to/profiles:/profiles `#optional` \
  -v /dev/input:/dev/input `#optional` \
  -v /run/udev/data:/run/udev/data `#optional` \
  --restart unless-stopped \
  lscr.io/linuxserver/kasm:latest
