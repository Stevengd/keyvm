#!/bin/bash

sudo docker pull splunk/splunk:latest
sudo docker run -d -p 8000:8000 --name=splunk -e "SPLUNK_PASSWORD=Key5ight!" -e "SPLUNK_START_ARGS=--accept-license"  splunk/splunk:latest


printf '%10s %32s %32s\n' interface ipaddress macaddress
printf '%s\n' '----------------------------------------------------------------------------'
for each in $(ip address | grep -oP '(^[\d]+:\s)\K[\d\w]+'); do
  mac=$(ip address show ${each} | grep -oP '(?<=link/ether\s)\K[\da-f:]+|(?<=link/loopback\s)\K[\da-f:]+')
  for address in $(ip address show ${each} | grep -oP '(?<=inet\s)\K[\d.]+|(?<=inet6\s)\K[\da-f:]+'); do
    printf '%10s %32s %32s\n' ${each} ${address} ${mac}
  done
done

echo "Use any external IP address to connect to Web UI on port 8000 (example https://192.168.10.10:8000)"
echo "User Login Information:  admin/Key5ight! "
read -n 1 -s -r -p "Press any key to continue"
