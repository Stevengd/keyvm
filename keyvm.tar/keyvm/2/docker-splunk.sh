#!/bin/bash

sudo docker pull splunk/splunk:latest
sudo docker run -d -p 8000:8000 -e "SPLUNK_PASSWORD=Key5ight!" -e "SPLUNK_START_ARGS=--accept-license"  splunk/splunk:latest
