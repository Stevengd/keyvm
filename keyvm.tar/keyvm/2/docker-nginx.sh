#!/bin/bash

refreshPermissions () {
    local pid="${1}"

    while kill -0 "${pid}" 2> /dev/null; do
        sudo -v
        sleep 10
    done
}

sudo -v
refreshPermissions "$$" &

sudo docker pull nginx
sudo docker run -d -p 80:80 nginx
