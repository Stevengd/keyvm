#!/bin/bash

sudo docker pull zevenet/zlb
sudo docker run --cap-add=NET_ADMIN -p 444:444 -p 80:80 -p 443:443 -d zevenet/zlb /bin/bash

