#!/bin/bash

sudo docker pull ubuntu
sudo docker run -id ubuntu sh
