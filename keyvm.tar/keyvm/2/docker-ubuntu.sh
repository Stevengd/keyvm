#!/bin/bash

sudo docker pull ubuntu
sudo docker run --name ubuntu --network host -id ubuntu sh
