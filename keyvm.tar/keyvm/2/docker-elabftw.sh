#!/bin/bash

sudo apt install mysql-server
sudo systemctl start mysql.service
curl -sL https://get.elabftw.net -o elabctl && chmod +x elabctl
sudo mv elabctl /usr/local/bin/
elabctl install
elabctl start
elabctl initialize

sudo docker ps -a
