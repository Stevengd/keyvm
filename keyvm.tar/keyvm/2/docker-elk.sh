#!/bin/bash

webip=$(ip -o route get to 8.8.8.8 | sed -n 's/.*src \([0-9.]\+\).*/\1/p')

sudo sysctl -w vm.max_map_count=262144
sudo docker pull sebp/elk
sudo docker run -d -p 5601:5601 -p 9200:9200 -p 5044:5044 --name=elk -e "discovery.type=single-node"  sebp/elk

sleep 2

printf '%10s %32s %32s\n' interface ipaddress macaddress
printf '%s\n' '----------------------------------------------------------------------------'
for each in $(ip address | grep -oP '(^[\d]+:\s)\K[\d\w]+'); do
  mac=$(ip address show ${each} | grep -oP '(?<=link/ether\s)\K[\da-f:]+|(?<=link/loopback\s)\K[\da-f:]+')
  for address in $(ip address show ${each} | grep -oP '(?<=inet\s)\K[\d.]+|(?<=inet6\s)\K[\da-f:]+'); do
    printf '%10s %32s %32s\n' ${each} ${address} ${mac}
  done
done

echo "Use any external IP address to connect to Web UI on port 5601 ==>  http://$webip:5601  "
read -n 1 -s -r -p "Press any key to continue"

exit
