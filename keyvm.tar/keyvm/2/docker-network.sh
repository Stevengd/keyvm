#!/bin/bash



net1eth= ip -o -f inet addr show | grep "ens33" | awk '/scope global/ {print $4}'
net1= $net1eth
echo $net1
net2eth= ip -o -f inet addr show | grep "ens34" | awk '/scope global/ {print $4}'
net2= $net2eth
echo $net2
gw1eth= /sbin/ip route |grep '^default' | awk '/ens33/ {print $3}'
gw1= $gw1eth
echo $gw1
gw2eth= /sbin/ip route |grep '^default' | awk '/ens34/ {print $3}'
gw2= $gw2eth
echo $gw2

sleep 2

docker network create -d macvlan --subnet=$net1 --gateway=$gw1  -o parent=ens33 dnet1
docker network create -d macvlan --subnet=$net2 --gateway=$gw2  -o parent=ens34 dnet2
