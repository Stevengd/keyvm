#!/bin/bash


echo "======================================"
echo "     QUICK NETWORK INFORMATION        "
echo "======================================"
printf '%10s %32s %32s\n' interface ipaddress macaddress
printf '%s\n' '----------------------------------------------------------------------------'
for each in $(ip address | grep -oP '(^[\d]+:\s)\K[\d\w]+'); do
  mac=$(ip address show ${each} | grep -oP '(?<=link/ether\s)\K[\da-f:]+|(?<=link/loopback\s)\K[\da-f:]+')
  for address in $(ip address show ${each} | grep -oP '(?<=inet\s)\K[\d.]+|(?<=inet6\s)\K[\da-f:]+'); do
    printf '%10s %32s %32s\n' ${each} ${address} ${mac}
  done
done

echo "============================================================================"


read -p "Which interface for the impairment policy? " nic

echo For Input use numerical form from .001 to 1000000. If not used, put 0 

#Rate Control
read -p " Rate Limits in mbit? " varbw 
varbw1="${varbw}mbit"

#Amount of Latency
read -p " Amount of Latency ms? " varlat
varlat1="${varlat}ms"

#Amount of Latency Variable
read -p  " Amount of Latency variation in ms? " varlatvar
varlatvar1="${varlatvar}ms"

#Amount of Packet Loss
read -p " Amount of Packet Loss in percentage? " varloss 
varloss1="${varloss}%"

#Amount of Packet duplication
read -p " Amount of Packet duplication in percentage? " vardup 
vardup1="${vardup}%"

#Amount of Packet Corruption
read -p " How much bit errors in percentage?  " varcor
varcor1="${varcor}%"

#Amount of Packet Reordering
read -p " Amount of Packet reorder in percentage? " varred
varred1="${varred}%"

#clear current config
sudo tc qdisc del dev $nic root netem 2>/dev/null || true

#apply new config
sudo tc qdisc add dev $nic root netem rate $varbw1 delay $varlat1 $varlatvar1 loss $varloss1 duplicate $vardup1 corrupt $varcor1 reorder $varred1



exit



















exit
