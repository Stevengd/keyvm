#!/bin/bash
 echo For Input use numerical form from .001 to 1000000. If not used, put 0 
#Interface Options
echo Which Interface to Modify? eth0 - WAN facing eth1 - Agent facing
read varint

#Rate Control
echo Rate Limits in mbit? 1000mbit
read varbw
varbw1="${varbw}mbit"

#Amount of Latency
echo Amount of Latency ms?
read varlat
varlat1="${varlat}ms"

#Amount of Packet Loss
echo Amount of Packet Loss in percentage? ex 10%
read varloss
varloss1="${varloss}%"

#Amount of Packet duplication
echo Amount of Packet duplication in percentage? ex 10%
read vardup
vardup1="${vardup}%"

#Amount of Packet Reordering
echo Amount of Packet reorder in percentage?
read varred
varred1="${varred}%"

#clear current config
sudo tc qdisc del dev $varint root netem

#apply new config
sudo tc qdisc add dev $varint root netem rate $varbw1 delay $varlat1 loss $varloss1 duplicate $vardup1 reorder $varred1




















exit