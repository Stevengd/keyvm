#!/bin/bash
 echo For Input use numerical form from .001 to 1000000. If not used, put 0 
#Interface Options
echo Which Interface to Modify? eth0 -To Agent4 eth1 - To WAN Eth2 - To Agent5
read varint

#Rate Control
echo Rate Limits in mbit? 1000mbit
read varbw
varbw1="${varbw}mbit"

#Amount of Latency
echo Amount of Latency ms?
read varlat
varlat1="${varlat}ms"

#Amount of Latency Variable
echo Amount of Latency variation in ms?
read varlatvar
varlatvar1="${varlatvar}ms"

#Type of Latency Distribution
echo Type of Latency Distribution? Choices: normal,pareto, or paretonormal
read varlatdis

#Amount of Packet Loss
echo Amount of Packet Loss in percentage? ex 10%
read varloss
varloss1="${varloss}%"

#Amount of Packet duplication
echo Amount of Packet duplication in percentage? ex 10%
read vardup
vardup1="${vardup}%"

#Amount of Packet Corruption
echo How much bit errors in percentage? ex 1%
read varcor
varcor1="${varcor}%"

#Amount of Packet Reordering
echo Amount of Packet reorder in percentage?
read varred
varred1="${varred}%"

#clear current config
sudo tc qdisc del dev $varint root netem

#apply new config
sudo tc qdisc add dev $varint root netem rate $varbw1 delay $varlat1 $varlatvar1 distribution $varlatdis loss $varloss1 duplicate $vardup1 corrupt $varcor1 reorder $varred1



















exit