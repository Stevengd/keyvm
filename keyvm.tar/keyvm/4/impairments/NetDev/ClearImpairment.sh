#!/bin/bash

echo Which Interface to clear? 
read varint

tc qdisc del dev $varint root netem

