#!/bin/bash

tc qdisc del dev ens160 root netem

