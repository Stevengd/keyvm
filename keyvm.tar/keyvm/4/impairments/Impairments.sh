 #!/bin/bash
 echo For Following question use numerical form from .001 to 1000000. If not used, put 0 
 #Rate Control
 echo Rate Limits in mbit? 
 read varbw
 varbw1="${varbw}mbit"


 #Amount of Latency
 echo Amount of Latency ms?
 read varlat
 varlat1="${varlat}ms"

 #Amount of Packet Loss
 echo Amount of Packet Loss in percentage? 
 read varloss
 varloss1="${varloss}%"


 #Amount of Packet duplication
 echo Amount of Packet duplication in percentage? 
 read vardup
 vardup1="${vardup}%"


 #Amount of Packet Reordering
 echo Amount of Packet reorder in percentage?
 read varred
 varred1="${varred}%"

 #clear current config
 tc qdisc del dev ens160 root netem

 #apply new config
 tc qdisc add dev ens160 root netem rate $varbw1 delay $varlat1 loss $varloss1 duplicate $vardup1 reorder $varred1

 exit




















exit