 #!/bin/bash

echo "======================================"
echo "     QUICK NETWORK INFORMATION        "
echo "======================================"
printf '%10s %32s %32s\n' interface ipaddress macaddress
printf '%s\n' '----------------------------------------------------------------------------'
for each in $(ip address | grep -oP '(^[\d]+:\s)\K[\d\w]+'); do
  mac=$(ip address show ${each} | grep -oP '(?<=link/ether\s)\K[\da-f:]+|(?<=link/loopback\s)\K[\da-f:]+')
  for address in $(ip address show ${each} | grep -oP '(?<=inet\s)\K[\d.]+|(?<=inet6\s)\K[\da-f:]+'); do
    printf '%10s %32s %32s\n' ${each} ${address} ${mac}
  done
done

echo "============================================================================"


read -p "Which interface for the impairment policy? " nic

echo For Following question use numerical form from .001 to 1000000. If not used, put 0 :

 #Amount of Latency
read -p " Amount of Latency ms? " varlat
varlat1="${varlat}ms"

 #Amount of Packet Loss
read -p " Amount of Packet Loss in percentage? " varloss 
varloss1="${varloss}%"

 #clear current config
sudo tc qdisc del dev $nic root netem 2>/dev/null || true

 #apply new config
sudo tc qdisc add dev $nic root netem delay $varlat1 loss $varloss1 

exit
