#!/bin/bash

cmd0=(dialog --keep-tite --menu "Select options:" 22 76 16)
options0=(1 "VM Configuration"
         2 "Docker Configuration"
         3 "Kubernetes Configuration"
         4 "Kubernetes Pod Setups"
	 5 "Configuration Reset")

choices0=$("${cmd0[@]}" "${options0[@]}" 2>&1 >/dev/tty)

for choice in $choices0
do
    case $choice in
        1)	echo "VM Initial Configurations"
	   	onoff=off
	   	cmd1=(dialog --radiolist "Select Service to configure" 22 76 16)
	    	load-dialog () {
    			options1=(
                		1 "HOSTNAME (no reboot)" $onoff
                		2 "IPADDRESS (no reboot)" $onoff
                		3 "HOSTNAME & IP (reboot automated)" $onoff
                		4 "MAIN SCREEN" $onoff
    	       		)
    	       		choices1=$("${cmd1[@]}" "${options1[@]}" 2>&1 >/dev/tty)
	    	}
	    	load-dialog
	    	#exit_code="$?"
	    	while [[ $exit_code -ne 0 ]]; do
	    	case $exit_code in
    			1) clear; onoff=off; load-dialog;;
    			3) clear; onoff=on; load-dialog;;
	    	esac
	    	exit_code="$?"
	    	done
	    	clear
	    	for choice in $choices1
	    	do
    	    	case $choice in
            		1)	echo "$contr - Configure Hostname"
				sudo ./keyvm/1/hostname.sh
           			sleep 2
           			exec "$0"
           			break;;

        		2)	echo "$contr - Configure IP"
				sudo ./keyvm/1/ip.sh
           		  	sleep 2
	   		  	exec "$0"
           		  	break;;

        		3)	echo "$contr - Configure Hostname and IP"
				sudo ./keyvm/1/hostip.sh
           		  	sleep 2
	   		  	exec "$0"
           			break;;

        		4) 	echo "Return to Menu"
				./keyvm/menu.sh
           			break;;
		  esac
		done
		sleep 1

	    ;;
        2)
            echo "Docker"
	    	onoff=off
	    	cmd2=(dialog --radiolist "Select Docker Containers to Install" 22 76 16)
	    	load-dialog () {
    			options2=(
                		P  "DOCKER PREREQS" $onoff
	           		1  "BUSYBOX" $onoff
                	 	2  "CHARIOT/HAWKEYE" $onoff
                	 	3  "CLOUDLENS" $onoff
                		4  "ELK" $onoff
               			5  "NGINX" $onoff
                		6  "NTOPNG" $onoff
                		7  "RDESKTOP" $onoff
                		8  "SPLUNK" $onoff
                		9  "UBUNTU" $onoff
				10 "WIRESHARK" $onoff
				11 "ZEVENET" $onoff
				12 "PLACEHOLDER" $onoff
				13 "ANSIBLE" $onoff
				14 "RETURN TO MAIN" $onoff
    	       		)
    	       		choices2=$("${cmd2[@]}" "${options2[@]}" 2>&1 >/dev/tty )
	    	}
	    	load-dialog
	    	#exit_code="$?"
	    	while [[ $exit_code -ne 0 ]]; do
	    	case $exit_code in
    			1) clear; onoff=off; load-dialog;;
    			3) clear; onoff=on; load-dialog;;
	    	esac
	    	#exit_code="$?"
	    	done
	    	clear
	    	for choice in $choices2
	    	do
    	    	case $choice in
            		P)  echo "Installing Docker PreRequisites"
           		    ./keyvm/2/docker-pre.sh
           		    sleep 2
           		    exec "$0"
           		    break;;

        		1)  echo "Installing BusyBox Container"
			    ./keyvm/2/docker-busybox.sh
           		    sleep 2
	   		    exec "$0"
           		    break;;

        		2)  echo "Installing Chariot/Hawkeye Container"
           		    ./keyvm/2/docker-chariot.sh
           		    sleep 2
	   		    exec "$0"
           		    break;;

        		3)  echo "Installing Cloudlens Container"
			    sudo ./keyvm/2/docker-cloudlens.sh
           	            sleep 1
	   		    exec "$0"
           		    break;;

        		4)  echo "Installing ELK Server Container"
           		    ./keyvm/2/docker-elk.sh
           		    sleep 2
	   		    exec "$0"
          		    break;;

        		5)  echo "Installing Nginx Server"
           		    ./keyvm/2/docker-nginx.sh
           		    sleep 2
	   		    exec "$0"
           		    break;;

        		6)  echo "Installing NTOPNG Server"
           		    ./keyvm/2/docker-ntopng.sh
           		    sleep 2
	   		    exec "$0"
           		    break;;

        		7)  echo "Installing Linux Jumpbox with GUI"
           		    ./keyvm/2/docker-rdesktop.sh
           		    sleep 2
	   		    exec "$0"
           		    break;;

        		8)  echo "Installing Splunk Server"
           		    ./keyvm/2/docker-splunk.sh
           		    sleep 2
	   		    exec "$0"
           		    break;;

        		9) echo "Installing Ubuntu Container"
            		    ./keyvm/2/docker-ubuntu.sh
			    sleep 2
			    exec "$0"
            		    break;;

        		10) echo "Installing Wireshark Container"
            		    ./keyvm/2/docker-wireshark.sh
			    sleep 2
			    exec "$0"
			    break;;

        		11) echo "Installing Zevenet LoadBalancer"
            		    ./keyvm/2/docker-zevenet.sh
			    sleep 2
			    exec "$0"
            		    break;;

		        12) echo "Installing Lab Automation"
			    #./keyvm/2/docker-elabftw.sh
			    sleep 2
			    exec "$0"
			    break;;

			13) echo "Installing Ansible Semaphore"
			    ./keyvm/2/docker-ansible.sh
			    sleep 2
			    exec "$0"
			    break;;

			14) ./keyvm/menu.sh
            		    break;;

    		esac
	     done
	     sleep 1
          ;;

        3)
            	echo "Kubernetes"
	            onoff=off
		    cmd3=(dialog --radiolist "Select Kubernetes Instructional" 0 0 0)
	    	    load-dialog () {
    			options3=(
                		 1 "Kubernetes PreReqs" $onoff
                		 2 "Kubernetes Standalone Host" $onoff
                		 3 "Kubernetes Master" $onoff
                		 4 "Kubernetes Worker" $onoff
                		 5 "Return to Main Menu" $onoff
    	       		)
    	       		choices3=$("${cmd3[@]}" "${options3[@]}" 2>&1 >/dev/tty)
	    	}
	    	load-dialog
	    	#exit_code="$?"
	    	while [[ $exit_code -ne 0 ]]; do
	    	case $exit_code in
    			1) clear; onoff=off; load-dialog;;
    			3) clear; onoff=on; load-dialog;;
	    	esac
	    	#exit_code="$?"
	    	done
	    	clear
	    	for choice in $choices3
	    	do
    	    	case $choice in
            			1)	echo "Installing Kubernetes PreReqs"
				        sudo ./keyvm/vf/3.sh
                                        sleep 3
           		    		sudo ./keyvm/3/kube-prep.sh
           		    		cd keyvm/3/yaml
					sudo ./cloudlens_info.sh
					sleep 2
					sudo rm variables.txt
                                        cd $h
           		    		exec "$0"
           		    		break;;

        			2)	echo "Installing Kuberenetes Standalone Host"
           		    		./keyvm/3/kubemaster-1.sh
           		    		sleep 2
	   		    		exec "$0"
           		    		break;;

        			3) 	echo "Configuring Kubernetes Master"
           				./keyvm/3/kube-master.sh
           				sleep 2
	   				exec "$0"
           				break;;

        			4) 	echo "Configuring Kubernetes Worker Node"
           				./keyvm/3/kube-worker.sh
					#./keyvm/3/cl/cloudlenskube.sh
					#./keyvm/3/cl/cloudlens-pod.sh
           				sleep 2
	   				exec "$0"
           				break;;

				5)	./keyvm/menu.sh
					break;;


		esac
	    done
	    sleep 1
                 ;;

        4)	echo "Kubernetes Pod  Setups"
            	onoff=off
                cmd4=(dialog --radiolist "Select Demo Setup" 0 0 0)
                load-dialog () {
                        options4=(
                                 1 "Nginx+Cloudlens Sidecar K8" $onoff
                                 2 "Cyperf K8" $onoff
                                 3 "Chariot+Cloudlens Sidecar" $onoff
                                 4 "Full Deployment Example" $onoff
				 5 "Cloudlens DaemonSet Deployment" $onoff
                                 6 "Terraform_GAIA" $onoff
                                 7 "Placeholder" $onoff
                                 8 "Placeholder" $onoff
                                 9 "Placeholder" $onoff
                                 10 "Return to Main Menu" $onoff
               		)
               		choices4=$("${cmd4[@]}" "${options4[@]}" 2>&1 >/dev/tty)
                }
                load-dialog
                #exit_code="$?"
                while [[ $exit_code -ne 0 ]]; do
                case $exit_code in
                        1) clear; onoff=off; load-dialog;;
                        3) clear; onoff=on; load-dialog;;
                esac
                #exit_code="$?"
                done
                clear
                for choice in $choices4
                do
                case $choice in
                                1)      echo "Installing Nginx + Cloudlens Pods"
					sudo ./keyvm/vf/2.sh
					cd keyvm/3/yaml
					sleep 1
					sudo ./cloudlens_info.sh
					./cloudlens_variables.sh
					sleep 2
					kubectl apply -f nginx-cloudlens.yaml
					kubectl get pods
					sleep 2
					kubectl get pods
					sleep 5
					cd $home
					sudo rm keyvm/3/yaml/variables.txt
                                        exec "$0"
                                        break;;

                                2)      echo "Installing Cyperf Pods"
					sudo ./keyvm/vf/2.sh
                                        cd keyvm/3/yaml
					echo pass 1
					sleep 1
					./cyperf_setup.sh
					echo pass 2
					sudo ./cyperf_variables.sh
					echo pass 3
                                        sleep 2
					kubectl apply -f cyperf-server.yml
					echo pass 4
					sleep 1
					cd $home
					sudo rm keyvm/3/yaml/variables.txt
					sleep 1
                                        exec "$0"
                                        break;;

                                3)      echo "Installing Chariot+Cloudlens Environment"
                                        sudo ./keyvm/vf/2.sh
					sleep 1
					cd keyvm/3/yaml
					sudo ./cloudlens_info.sh
                                        sleep 1
					./chariot_variable.sh
					sleep 1
					kubectl apply -f chariot-cloudlens.yaml
					sleep 30
					./chariot_setup.sh
					sleep 1
					cd $home
					sudo rm keyvm/3/yaml/variables.txt
                                        exec "$0"
                                        break;;

                                4)      echo "Full Deployment of Chariot + Cloudlens"
					sudo ./keyvm/vf/0.sh
					sleep 1
                                        sudo ./keyvm/1/1.sh
					sleep 1
                                        sudo ./keyvm/3/kube-prep.sh
					sleep 1
                                        ./keyvm/3/kubemaster-1.sh
                                        sleep 1
					cd keyvm/3/yaml

					sudo ./cloudlens_info.sh
					sleep 1
					./chariot_variable.sh
					sleep 1
					kubectl apply -f chariot-cloudlens.yaml
					sleep 30
					./chariot_setup.sh
					sleep 1
					cd $home
					sudo rm keyvm/3/yaml/variables.txt
                                        exec "$0"
                                        break;;

				5)      echo "Installing DaemonSet"
                                        sudo ./keyvm/vf/4.sh
                                        sleep 1
				        cd keyvm/3/yaml
                                        ./daemonset-cloudlens.sh
					sleep 1 
				        sudo rm variables.txt
                                        break;;

			        6)      echo "Installing Terraform GAIA"
                                        ./keyvm/3/yaml/terraform.sh
					sleep 1
				        exec "$0"
                                        break;;

			        7)      ./keyvm/menu.sh
                                        break;;

		                8)      ./keyvm/menu.sh
                                        break;;

		                9)      ./keyvm/menu.sh
                                        break;;

		                10)      ./keyvm/menu.sh
                                         break;;



                    esac
            	done
            	sleep 1
            ;;

        5)	echo "Configuration Resets"
            	onoff=off
                cmd4=(dialog --radiolist "Select Demo Setup" 0 0 0)
                load-dialog () {
                        options4=(
                                 1 "Delete all Docker Containers" $onoff
                                 2 "Reset Kubernetes (requires Kube reinitialization)" $onoff
                                 3 "Delete all Kubernetes Pods" $onoff
                                 4 "Placeholder" $onoff
				 5 "Return to Main Menu" $onoff
               		)
               		choices4=$("${cmd4[@]}" "${options4[@]}" 2>&1 >/dev/tty)
                }
                load-dialog
                #exit_code="$?"
                while [[ $exit_code -ne 0 ]]; do
                case $exit_code in
                        1) clear; onoff=off; load-dialog;;
                        3) clear; onoff=on; load-dialog;;
                esac
                #exit_code="$?"
                done
                clear
                for choice in $choices4
                do
                case $choice in
                                1)      echo "Deleting all Docker Containers"
                                        sudo ./keyvm/ts/del_dc.sh
					sleep 2
                                        exec "$0"
                                        break;;

                                2)      echo "Resetting Kubernetes"
                                        sudo ./keyvm/ts/reset_kube.sh
                                        sleep 2
                                        exec "$0"
                                        break;;

                                3)      echo "Deleting Kubernetes Pods"
                                        ./keyvm/ts/del_pods.sh
					sleep 2
                                        exec "$0"
                                        break;;

                                4)      echo "Full Deployment example"
		 	 		sudo ./keyvm/vf/0.sh
                                        exec "$0"
                                        break;;

				5)      ./keyvm/menu.sh
                                        break;;

                    esac
            	done
            	sleep 1
            ;;


    esac
done
sleep 1
