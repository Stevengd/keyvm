#!/usr/bin/env bash

refreshPermissions () {
    local pid="${1}"

    while kill -0 "${pid}" 2> /dev/null; do
        sudo -v
        sleep 10
    done
}

sudo -v
refreshPermissions "$$" &

#change machine-id
sudo rm /etc/machine-id
sudo dbus-uuidgen --ensure=/etc/machine-id
sudo dbus-uuidgen --ensure


# Retrieves the NIC information
print "==================================="
sudo netplan get
print "==================================="
ifconfig
print "==================================="
sleep 1

# Ask for input on network configuration
read -p "Enter the static IP of ens33 in CIDR notation: " staticip
read -p "Enter the gateway for ens33: " gatewayip
read -p "Enter the IP of preferred nameservers (seperated by a coma if more than one): " nameserversip
read -p "Enter the static IP of ens34 in CIDR  (optional):" staticip2

#apply configurations
sudo netplan set ethernets.ens33.addresses=[$staticip]
sudo netplan set ethernets.ens33.dhcp4=false
sudo netplan set ethernets.ens33.mtu=9000
sudo netplan set ethernets.ens33.gateway4=$gatewayip
sudo netplan set ethernets.ens33.nameservers.addresses=[$nameserversip]
sudo netplan set ethernets.ens34.addresses=[$staticip2]
sudo netplan set ethernets.ens34.dhcp4=true
sudo netplan set ethernets.ens34.mtu=9000

sleep  1
sudo netplan apply


echo "==========================="
sleep 2
read -p "Enter Hostname:" hostnameid
sudo hostnamectl set-hostname $hostnameid
sudo netplan apply
echo "=========================="


echo


sudo cat > keyvm/vf/variables.txt <<EOF

staticip=$staticip
staticip2=$staticip2
gatewayip=$gatewayip
nameserverip=$nameserverip
hostnameid=$hostnameid

EOF

echo "==========================="
echo "IP_ADDRESS: $staticip"
echo "GATEWAY_ADDRESS: $gatewayip"
echo "DNS_SERVER: $nameserverip"
echo "VM NAME: $hostnameid"
echo "=========================="

sleep 3
