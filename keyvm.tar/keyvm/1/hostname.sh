#!/usr/bin/env bash

read -p "Enter Hostname:" hostnameid
sudo hostnamectl set-hostname $hostnameid

cat <<EOF | sudo tee /etc/hostname
$hostnameid
EOF

echo "VM will now reboot"
sleep 5
sudo reboot

