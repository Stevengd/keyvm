#!/bin/bash
#change machine-id
sudo rm /etc/machine-id
sudo dbus-uuidgen --ensure=/etc/machine-id
sudo dbus-uuidgen --ensure
# Creates a backup
cp /etc/netplan/00-installer-config.yaml /etc/netplan/netplan00.yaml.bk_`date +%Y%m%d%H%M`
# Changes dhcp from 'yes' to 'no'
sed -i "s/dhcp4: yes/dhcp4: false/g" /etc/netplan/00-installer-config.yaml
# Retrieves the NIC information
nic1=`ifconfig | awk 'NR==1{print $1}'`
#nic2=`ifconfig | awk 'NR==10{print $1}'`
#nic3=`ifconfig | awk 'NR==17{print $1}'`
# Ask for input on network configuration
read -p "Enter the static IP of the server in CIDR notation: " staticip
read -p "Enter the IP of your gateway: " gatewayip
read -p "Enter the IP of preferred nameservers (seperated by a coma if more than one): " nameserversip
echo
cat > /etc/netplan/00-installer-config.yaml <<EOF
network:
  version: 2
  renderer: networkd
  ethernets:
    $nic1
      mtu: 9000
      addresses: [$staticip]
      gateway4: $gatewayip
      nameservers:
        addresses: [$nameserversip]
#    $nic2
#      dhcp4: true
#    $nic3
#      dhcp4: true
EOF


echo "==========================="
sleep 10
read -p "Enter Hostname:" hostnameid
sudo hostnamectl set-hostname $hostnameid
sudo netplan apply
echo "=========================="
echo "VM will now reboot"
sleep 5
sudo reboot
echo
