#!/bin/bash


refreshPermissions () {
    local pid="${1}"

    while kill -0 "${pid}" 2> /dev/null; do
        sudo -v
        sleep 10
    done
}

sudo -v
refreshPermissions "$$" &


# Retrieves the NIC information
echo "==================================="
sudo netplan get
echo "==================================="
echo "Available Interfaces:"
#ip -o link | awk '{print $2,$(NF-2),$(NF-4)}'
#echo "======================================"
printf '%10s %32s %32s\n' interface ipaddress macaddress
printf '%s\n' '----------------------------------------------------------------------------'
for each in $(ip address | grep -oP '(^[\d]+:\s)\K[\d\w]+'); do
  mac=$(ip address show ${each} | grep -oP '(?<=link/ether\s)\K[\da-f:]+|(?<=link/loopback\s)\K[\da-f:]+')
  for address in $(ip address show ${each} | grep -oP '(?<=inet\s)\K[\d.]+|(?<=inet6\s)\K[\da-f:]+'); do
    printf '%10s %32s %32s\n' ${each} ${address} ${mac}
  done
done

# Ask for input on network configuration
read -p "Enter interface for nic1: " nic1
read -p "Enable DHCP for nic1 (true/false): " dhcp1
read -p "Enter the static IP of nic1 in CIDR notation(leave blank if DHCP enabled): " staticip
read -p "Enter the gateway for nic1(leave blank if DHCP enabled): " gatewayip
read -p "Enter the IP of preferred nameservers (seperated by a coma if more than one): " nameserversip
read -p "Enter interface for nic2: " nic2
read -p "Enable DHCP for nic2 (true/false): " dhcp2
read -p "Enter the static IP of nic2 in CIDR  (leave blank if DHCP enabled):" staticip2

#apply configurations
sudo netplan set ethernets.$nic1.addresses=[$staticip]
sudo netplan set ethernets.$nic1.dhcp4=$dhcp1
sudo netplan set ethernets.$nic1.mtu=9000
sudo netplan set ethernets.$nic1.gateway4=$gatewayip
sudo netplan set ethernets.$nic1.nameservers.addresses=[$nameserversip]
sudo netplan set ethernets.$nic2.addresses=[$staticip2] 
sudo netplan set ethernets.$nic2.dhcp4=$dhcp2
sudo netplan set ethernets.$nic2.mtu=9000

sleep  1
sudo netplan apply
sudo netplan  get
