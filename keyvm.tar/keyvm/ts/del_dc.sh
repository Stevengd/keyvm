#!/usr/bin/env bash

#stop all containers

sudo docker stop $(sudo docker ps -a -q)

#delete all containers

sudo docker rm $(sudo docker ps -a -q)

#delete all images

sudo docker image rm $(sudo docker images)
