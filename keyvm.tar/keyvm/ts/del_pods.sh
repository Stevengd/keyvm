#1/usr/bin/env bash


#delete all deployments

kubectl delete deployments --all
