#!/usr/bin/env bash

#delete all kube configuration

yes | sudo kubeadm reset

sleep 2

sudo rm -r .kube/

